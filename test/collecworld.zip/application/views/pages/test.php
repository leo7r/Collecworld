<script>
	
	$(document).ready(function(){
	
		$("#prueba").load(path+'ajax/mini-explore/mini-explore.php',{category:1,type:'buy',user_id:16,step:0,pre:1059});
	});
	
</script>
<div>
Prueba mini fru
</div>
<div id="prueba" style="width:960px; margin-left:auto; margin-right:auto;"></div>