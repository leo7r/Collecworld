<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.js" ></script>
<script>
	$(document).ready(function(){
		history.go(-1);
	});
</script>